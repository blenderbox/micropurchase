#
#   ____  _____  ______ _   _   ____ _____ _____  
#  / __ \|  __ \|  ____| \ | | |  _ \_   _|  __ \ 
# | |  | | |__) | |__  |  \| | | |_) || | | |  | |
# | |  | |  ___/|  __| | . ` | |  _ < | | | |  | |
# | |__| | |    | |____| |\  | | |_) || |_| |__| |
#  \____/|_|    |______|_| \_| |____/_____|_____/  v1
#
# Usage:
#
# 	source open_bid_v1_setup.sh
# 
# You will be prompted for your github account credentials.
#
# If you are running this at DORIS, make sure your proxy is set.
# See /etc/profile.d/proxy.sh
#
# !!! ATTENTION !!!
# -----------------
# Only run this script *after* having run subscribe.sh
#

# Color setup
red=`tput setaf 1`
green=`tput setaf 2`
reset=`tput sgr0`

# Configure to obtain software from the Optional RPMs and RHSCL software repositories
sudo subscription-manager repos --enable rhel-server-rhscl-6-rpms
sudo subscription-manager repos --enable rhel-6-server-optional-rpms

# move to shared vagrant folder
cd /vagrant

# Install git
sudo yum -y install git

# Install nano (for us non vi folk)
sudo yum -y install nano

# clone blenderbox fork of micropurchase git repo (change this to gitlab for DoITT production?)
git clone https://github.com/blenderbox/micropurchase.git

echo "------------- START OPEN BID DB SERVER SETUP ------------"

# Install postgres
sudo yum -y install rh-postgresql95
sudo yum -y install rh-postgresql95-postgresql-devel
source /opt/rh/rh-postgresql95/enable

# need to fix some symbolic links for lipq.so
sudo ln -s /opt/rh/rh-postgresql95/root/usr/lib64/libpq.so.rh-postgresql95-5.8 /usr/lib64/libpq.so.rh-postgresql95-5
sudo ln -s /opt/rh/rh-postgresql95/root/usr/lib64/libpq.so.rh-postgresql95-5.8 /usr/lib/libpq.so.rh-postgresql95-5
echo "=====> postgres cleanup: setting up symbolic link to libpq shared library"
libpq=/usr/lib/libpq.so.rh-postgresql95-5
if [ ! -L $libpq ]; then
  echo "${red}=====> libpq link doesn't exist${reset}"
else
  echo "=====> symbolic link worked!"
fi

echo "=====> Initializing database"
sudo /opt/rh/rh-postgresql95/root/usr/bin/postgresql-setup --initdb
if [ $? -eq 0 ]; then
    echo "=====> SUCCESS!"
else
    echo "${red}=====> FAIL${reset}"
fi

# Start the postgres server
echo "=====> Starting Postgres Server"
sudo service rh-postgresql95-postgresql start
if [ $? -eq 0 ]; then
    echo "=====> SUCCESS!"
else
    echo "${red}=====> FAIL${reset}"
fi

# Create the vagrant database role
echo "=====> creating database user for vagrant"
sudo -u postgres /opt/rh/rh-postgresql95/root/usr/bin/createuser -s -e vagrant
if [ $? -eq 0 ]; then
    echo "=====> SUCCESS!"
else
    echo "${red}=====> FAIL${reset}"
fi

echo "=====> adding postgres to startup services"
sudo chkconfig --add rh-postgresql95-postgresql
sudo chkconfig rh-postgresql95-postgresql on
chkconfig --list | grep npostgresql
chkconfig postgresql95-postgresql && echo "=====> nginx service is configured"

echo "=====> adding postgresql95 to path"
export PATH="/opt/rh/rh-postgresql95/root/usr/bin":$PATH



echo "------------- END OPEN BID DB SERVER SETUP ------------"

echo "------------- START OPEN BID WEB SERVER SETUP ------------"

# Install Ruby 2.3
sudo yum -y install rh-ruby23
source /opt/rh/rh-ruby23/enable

# Install Ruby devel and other required libraries
sudo yum -y install rh-ruby23-ruby-devel.x86_64
sudo yum -y install gcc-c++
sudo yum -y install libxml2-devel

# Install Ruby On Rails 4.2
sudo yum -y install rh-ror42
source /opt/rh/rh-ror42/enable

# Install Passenger 4.0
sudo yum -y install rh-passenger40
source /opt/rh/rh-passenger40/enable

# Install nginx 1.6
sudo yum -y install nginx16
source /opt/rh/nginx16/enable

# auto start nginx
echo "=====> adding auto start to nginx service with chkconfig"
sudo chkconfig --add nginx16-nginx
sudo chkconfig nginx16-nginx on
chkconfig --list | grep nginx
chkconfig nginx16-nginx && echo "=====> nginx service is configured"

# make a symbolic link to our nginx.conf that's under version control
echo "=====> removing default nginx.conf and making symbolic link to nginx.conf under version control"
sudo rm -Rf /opt/rh/nginx16/root/etc/nginx/nginx.conf
if [ $? -eq 0 ]; then
    echo "=====> SUCCESS!"
else
    echo "${red}=====> FAIL${reset}"
fi

sudo ln -s /vagrant/config/nginx/nginx.conf /opt/rh/nginx16/root/etc/nginx/nginx.conf
nginx=/opt/rh/nginx16/root/etc/nginx/nginx.conf
if [ ! -L $nginx ]; then
  echo "${red}=====> nginx.conf link doesn't exist${reset}"
else
  echo "=====> symbolic link worked!"
fi

echo "=====> Starting nginx..."
sudo service nginx16-nginx start
if [ $? -eq 0 ]; then
    echo "=====> SUCCESS!"
else
    echo "${red}=====> FAIL${reset}"
fi

echo "=====> Adding enabled services to bash"
# "Auto-enable"
sudo bash -c "printf 'source /opt/rh/rh-ruby23/enable\nsource /opt/rh/rh-ror42/enable\nsource /opt/rh/rh-passenger40/enable\nsource /opt/rh/nginx16/enable\nsource /opt/rh/rh-postgresql95/enable\nsource /opt/rh/rh-nodejs4/enable
' > /etc/profile.d/enable.sh"

echo "------------- END OPEN BID WEB SERVER SETUP ------------"

# update bundler
echo "=====> updating rails and bundler"
gem update rails
gem install bundler

# install gems
echo "=====> installing gems"
cd /vagrant/micropurchase
bundle install
# ok, some of the gems from the rh software collection may be stale, so let's clean up
gem clean
gem install debug_inspector --force
# let's go through one more time (we were having an issue with the compiled version of debug_inspector gem which should be cleaned up now)
bundle install

echo "------------- (ALMOST) DONE! ------------"
printf "\nPlease reboot now:\n\n"
printf "\t$ exit\n"
printf "\t$ vagrant reload\n\n"
printf "\t$ vagrant ssh\n\n"
printf "\t\t$ cd /vagrant/micropurchase\n"
printf "\t\t$ rake db:create\n"
printf "\t\t$ rake db:migrate\n"
printf "\t\t$ sudo service nginx16-nginx restart\n\n"
printf "\t$ then check the vm configured network web port e.g. http:127.0.0.1:4567\n\n"
